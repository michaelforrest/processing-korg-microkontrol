package microkontrol.controls;

public class Pad extends Button {

}
