package microkontrol.controls;

import java.util.Observable;

public class Joystick extends Observable {

}
