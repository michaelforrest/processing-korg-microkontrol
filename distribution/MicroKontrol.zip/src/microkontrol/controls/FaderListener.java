package microkontrol.controls;

public interface FaderListener {
	void moved(Float proportion);
}
