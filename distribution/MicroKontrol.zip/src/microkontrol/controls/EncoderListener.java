package microkontrol.controls;

public interface EncoderListener{
	void moved(Integer change);
}
